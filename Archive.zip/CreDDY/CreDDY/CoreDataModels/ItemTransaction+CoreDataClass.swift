//
//  ItemTransaction+CoreDataClass.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 17/01/22.
//
//

import Foundation
import CoreData

@objc(ItemTransaction)
public class ItemTransaction: NSManagedObject {

}
