//
//  Item+CoreDataProperties.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 17/01/22.
//
//

import Foundation
import CoreData


extension Item {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        return NSFetchRequest<Item>(entityName: "Item")
    }

    @NSManaged public var cost: Double
    @NSManaged public var image: String?
    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var quantity: Float
    @NSManaged public var quantityType: String?
    @NSManaged public var transaction: ItemTransaction?

    public var wrappedName: String {
        name ?? "Unknown name"
    }
}

extension Item : Identifiable {

}
