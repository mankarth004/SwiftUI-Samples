//
//  ItemTransaction+CoreDataProperties.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 17/01/22.
//
//

import Foundation
import CoreData


extension ItemTransaction {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ItemTransaction> {
        return NSFetchRequest<ItemTransaction>(entityName: "ItemTransaction")
    }

    @NSManaged public var date: Date?
    @NSManaged public var id: UUID?
    @NSManaged public var items: NSSet?
    @NSManaged public var customer: Customer?
    @NSManaged public var isPartial: Bool
    @NSManaged public var isDue: Bool
    @NSManaged public var pendingAmount: Double
    @NSManaged public var total: Double
    @NSManaged public var paidAmount: Double
    
    public var wrappedDate: Date {
        date ?? Date()
    }
    public var itemsArray: [Item] {
        let set = items as? Set<Item> ?? []
        return set.sorted {
            $0.wrappedName < $1.wrappedName
        }
    }
}

// MARK: Generated accessors for items
extension ItemTransaction {

    @objc(addItemsObject:)
    @NSManaged public func addToItems(_ value: Item)

    @objc(removeItemsObject:)
    @NSManaged public func removeFromItems(_ value: Item)

    @objc(addItems:)
    @NSManaged public func addToItems(_ values: NSSet)

    @objc(removeItems:)
    @NSManaged public func removeFromItems(_ values: NSSet)

}

extension ItemTransaction : Identifiable {

}

extension ItemTransaction {
    var transactionTotal: Double {
        let itemCosts = self.itemsArray.map {$0.cost * Double($0.quantity)}
        let total = itemCosts.reduce(0, +)
        return total.rounded(toPlaces: 1)
    }
}
