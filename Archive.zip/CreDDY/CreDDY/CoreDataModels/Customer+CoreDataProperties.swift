//
//  Customer+CoreDataProperties.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 17/01/22.
//
//

import Foundation
import CoreData


extension Customer {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Customer> {
        return NSFetchRequest<Customer>(entityName: "Customer")
    }

    @NSManaged public var address: String?
    @NSManaged public var createdDate: Date?
    @NSManaged public var id: UUID?
    @NSManaged public var dueAmount: Double
    @NSManaged public var dueDate: Date?
    @NSManaged public var email: String?
    @NSManaged public var isDue: Bool
    @NSManaged public var mobile: String?
    @NSManaged public var name: String?
    @NSManaged public var totalAmount: Double
    @NSManaged public var transactions: NSSet?

    public var wrappedName: String {
        name ?? "Unknown name"
    }
    
    public var transactionArray: [ItemTransaction] {
        let set = transactions as? Set<ItemTransaction> ?? []
        return set.sorted {
            $0.wrappedDate < $1.wrappedDate
        }
    }
}

extension Customer {
    public var totalPendingAmount: Double {
        let pendingAmounts = transactionArray.map {$0.pendingAmount}
        let total = pendingAmounts.reduce(0, +)
        return total.rounded(toPlaces: 1)
    }
}
// MARK: Generated accessors for transactions
extension Customer {

    @objc(addTransactionsObject:)
    @NSManaged public func addToTransactions(_ value: ItemTransaction)

    @objc(removeTransactionsObject:)
    @NSManaged public func removeFromTransactions(_ value: ItemTransaction)

    @objc(addTransactions:)
    @NSManaged public func addToTransactions(_ values: NSSet)

    @objc(removeTransactions:)
    @NSManaged public func removeFromTransactions(_ values: NSSet)

}

extension Customer : Identifiable {

}
