//
//  Customer+CoreDataClass.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 17/01/22.
//
//

import Foundation
import CoreData


public class Customer: NSManagedObject {

}
