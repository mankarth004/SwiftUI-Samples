//
//  StateManager.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 19/01/22.
//

import Foundation
class StateManager: ObservableObject {
    @Published var tabSelection: Int = 1
}
