//
//  PDFViewer.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 21/01/22.
//

import Foundation
import PDFKit
import SwiftUI

import PDFKit
struct PDFKitView: View {
    var url: URL
    var body: some View {
        PDFKitRepresentedView(url)
    }
}

struct PDFKitRepresentedView: UIViewRepresentable {
    let url: URL
    init(_ url: URL) {
        self.url = url
    }

    func makeUIView(context: UIViewRepresentableContext<PDFKitRepresentedView>) -> PDFKitRepresentedView.UIViewType {
        let pdfView = PDFView()
//        load local pdf
//        if let path = Bundle.main.path(forResource: "sample", ofType: "pdf") {
//            let url = URL.init(fileURLWithPath: path)
//        }
        do {
            let data = try Data(contentsOf: url)
            pdfView.document = PDFDocument(data: data)
            pdfView.autoScales = true
        } catch {
            print(error.localizedDescription)
        }
        return pdfView
    }

    func updateUIView(_ uiView: UIView, context: UIViewRepresentableContext<PDFKitRepresentedView>) {
        // Update the view.
    }
}
