//
//  Extensions.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 17/01/22.
//

import Foundation
import UIKit

extension Date {
    var fullDateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy hh:mm a"
        formatter.calendar = .current
        formatter.timeZone = .current
        formatter.locale = .current
        return formatter.string(from: self)
    }
}
extension Double {
    /// Rounds the double to decimal places value
    func rounded(toPlaces places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
    var rupeeFormat: String {
        return String(format: "₹%0.1f", rounded(toPlaces: 1))
    }
}

extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
