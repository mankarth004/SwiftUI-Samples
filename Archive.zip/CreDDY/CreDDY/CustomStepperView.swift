//
//  CustomStepperView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 10/01/22.
//

import SwiftUI

struct CustomStepperView: View {
    @Binding var value: Int
    var body: some View {
        HStack {
            if value == 0 {
                Text("Add item")
                    .foregroundColor(.white)
                    .font(.headline)
            }else{
                Button {
                    value -= 1
                } label: {
                    Image(systemName: "minus.circle")
                }
                .foregroundColor(.white)
                .font(.headline)
                Text("\(value)")
                    .foregroundColor(.white)
                    .font(.headline)
            }
            Button {
                value += 1
            } label: {
                Image(systemName: "plus.circle")
            }
            .foregroundColor(.white)
            .font(.headline)
        }
        .padding(6)
        .background(Color.accentColor)
        .clipShape(Capsule())
    }
}

struct SampleButton_Previews: PreviewProvider {
    static var previews: some View {
        CustomStepperView(value: .constant(0))
    }
}
