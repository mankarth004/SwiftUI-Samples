//
//  CustomerDetailView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 07/01/22.
//

import SwiftUI
import CoreData

struct FilteredList<T: NSManagedObject, Content: View>: View {
    var fetchRequest: FetchRequest<T>
    var items: FetchedResults<T> { fetchRequest.wrappedValue }

    let content: (T) -> Content

    var body: some View {
        List(items, id: \.self) { item in
            self.content(item)
        }
    }

    init(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor] = [], @ViewBuilder content: @escaping (T) -> Content) {
        fetchRequest = FetchRequest<T>(entity: T.entity(), sortDescriptors: sortDescriptors, predicate: predicate)
        self.content = content
    }
}

struct TransactionList: View {
    @ObservedObject var customer: Customer
    var body: some View {
        FilteredList(predicate: NSPredicate(format: "customer.id=%@", customer.id! as CVarArg), sortDescriptors: [NSSortDescriptor(keyPath: \ItemTransaction.date, ascending: false)]) { (transaction: ItemTransaction) in
            NavigationLink {
                TransactionDetailView(transaction: transaction)
            } label: {
                HStack {
                    VStack(alignment: .leading) {
                        Text(transaction.wrappedDate.fullDateString)
                            .font(.subheadline)
                            .fixedSize(horizontal: false, vertical: true)
                        HStack {
                            Text("items: \(transaction.itemsArray.count)")
                                .foregroundColor(.gray)
                            Divider()
                                .foregroundColor(.gray)
                            if transaction.isPartial && transaction.isDue {
                                Text("partial")
                                    .foregroundColor(.blue)
                                    .fontWeight(.medium)
                            }else{
                                Text(transaction.isDue ? "due" : "paid")
                                    .foregroundColor(transaction.isDue ? .red : .green)
                                    .fontWeight(.medium)
                            }
                        }
                        .font(.footnote)
                        if transaction.isPartial && !transaction.pendingAmount.isZero {
                            HStack {
                                Text(String.init(format: "paid: ₹%0.1f", transaction.paidAmount))
                                    .foregroundColor(.gray)
                                Divider()
                                    .foregroundColor(.gray)
                                Text(String.init(format: "total: ₹%0.1f", transaction.total))
                                    .foregroundColor(.gray)
                            }
                            .font(.footnote)
                        }
                    }
                        Spacer()
                    Text(String.init(format: "₹%0.1f", transaction.isDue ? transaction.pendingAmount : transaction.total))
                            .font(.title2)
                            .fontWeight(.medium)
                            .foregroundColor(transaction.isDue ? .red : .green)
                }
            }
        }
    }
}

struct CustomerDetailView: View {
    @Environment(\.managedObjectContext) var viewContext

    @ObservedObject var customer: Customer
    
    @State var presentingModal = false

    @State var name: String = ""
    @State var mobile: String = ""
    @State var email: String = ""
    @State var address: String = ""
    
    var body: some View {
            Form {
                Section(header:
                            HStack{
                    Text("Profile Details")
                }) {
                    HStack {
                        Text("Name")
                            .font(.footnote)
                            .foregroundColor(.gray)
                        TextField("Enter customer name", text: $name)
                            .multilineTextAlignment(.trailing)
                            .font(.subheadline)
                    }
                    HStack {
                        Text("Mobile")
                            .font(.footnote)
                            .foregroundColor(.gray)
                        TextField("Enter mobile number", text: $mobile)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.phonePad)
                            .font(.subheadline)
                    }
                    HStack {
                        Text("Email")
                            .font(.footnote)
                            .foregroundColor(.gray)
                        TextField("Enter emailId", text: $email)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.emailAddress)
                            .textCase(.lowercase)
                            .font(.subheadline)
                    }
                    VStack(alignment: .leading){
                        Text("Address")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.bottom, -10)
                        TextEditor(text: $address)
                            .font(.subheadline)
                    }
                }
                Section(header:
                            HStack{
                    Text("Transactions")
                }) {
                    // list for transactions
                    TransactionList(customer: customer)
                }
            }.onAppear(perform: {
                name = customer.name ?? ""
                mobile = customer.mobile ?? ""
                email = customer.email ?? ""
                address = customer.address ?? ""
            })
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: addItems) {
                        Text("Add Items")
                    }.sheet(isPresented: $presentingModal) {
                        ItemListView(listType: .constant(.addToCustomer)){ items in
                            let transaction = ItemTransaction(context: viewContext)
                            transaction.date = Date()
                            transaction.id = UUID()
                            for item in items {
//                                Creating new object from existing object
                                let newItem = Item(context: viewContext)
                                newItem.name = item.name
                                newItem.id = UUID()
                                newItem.quantity = item.quantity
                                newItem.quantityType = item.quantityType
                                newItem.cost = item.cost
                                newItem.image = item.image
                                transaction.addToItems(newItem)
                                
//                                Discarding changes of existing item
                                viewContext.refresh(item, mergeChanges: false)
                            }
                            transaction.total = transaction.transactionTotal
                            transaction.pendingAmount = transaction.transactionTotal
                            customer.addToTransactions(transaction)
                            do {
                                try viewContext.save()
                            } catch {
                                print(error)
                            }
                        }.environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                    }
                }
            }
            .navigationTitle(customer.name ?? "")
    }
    private func addItems() {
        presentingModal = true
    }
    private func addCustomer() {
        guard !name.isEmpty && !mobile.isEmpty else {
            return
        }
        UIApplication.shared.endEditing()
        guard let entity = NSEntityDescription.entity(forEntityName: "Customer", in: viewContext) else { return }
        let customer = Customer(entity: entity, insertInto: viewContext)
        customer.name = name
        customer.mobile = mobile
        customer.email = email
        customer.address = address
        customer.createdDate = Date()
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}

struct CustomerDetailView_Previews: PreviewProvider {
    static let persistence = PersistenceController.preview
    
    static var customer: Customer = {
        let context = persistence.container.viewContext
        let item = Customer(context: context)
        item.name = "John Doe"
        return item
    }()
    static var previews: some View {
        CustomerDetailView(customer: customer).environment(\.managedObjectContext, persistence.container.viewContext)
    }
}
