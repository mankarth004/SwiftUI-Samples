//
//  AddItemView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 03/01/22.
//

import SwiftUI
import CoreData

struct ListHeader: View {
    let imageWidth = 100.0
    @Binding var image: UIImage?
    var body: some View {
        VStack {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .frame(width: imageWidth, height: imageWidth, alignment: .center)
                    .cornerRadius(.infinity)
            } else {
                Image(systemName: "pencil.circle.fill")
                    .resizable()
                    .frame(width: imageWidth, height: imageWidth, alignment: .center)
                    .foregroundColor(.accentColor)
            }
            Text("Edit photo").font(.footnote).foregroundColor(.accentColor)
        }.background(Color.clear)
    }
}

struct AddItemView: View {
    @Environment(\.managedObjectContext) var viewContext

    @Binding var presentedAsModal: Int?
    
    @State var showAction: Bool = false
    @State var showImagePicker: Bool = false
    
    @State var uiImage: UIImage? = nil
    
    @State var name: String = ""
    @State var quantityType: Int = 0
    @State var cost: String = ""
    
    var sheet: ActionSheet {
        ActionSheet(
            title: Text("Choose an option"),
            message: nil,
            buttons: [
                .default(Text("Pick from photos"), action: {
                    self.showAction = false
                    self.showImagePicker = true
                }),
                .default(Text("Open camera"), action: {
                    self.showAction = false
                    self.showImagePicker = true
                }),
                .cancel(Text("Close"), action: {
                    self.showAction = false
                })
            ])
    }

    var body: some View {
        VStack {
            ListHeader(image: $uiImage)
                .onTapGesture {
//                    self.showAction = true
                    self.showImagePicker = true
                }
                .sheet(isPresented: $showImagePicker, onDismiss: {
                    self.showImagePicker = false
                }, content: {
                    ImagePicker(isShown: self.$showImagePicker, uiImage: self.$uiImage)
                })
            
                .actionSheet(isPresented: $showAction) {
                    sheet
                }
            Form {
                Section(header: Text("Item Details")) {
                    HStack {
                        Text("Name")
                        TextField("Enter item name", text: $name).keyboardType(.asciiCapable).multilineTextAlignment(.trailing)
                    }
                    HStack {
                        Text("Cost")
                        TextField("Enter item cost", text: $cost).keyboardType(.decimalPad).multilineTextAlignment(.trailing)
                    }
                    Picker("QuantityType", selection: $quantityType) {
                        Text("g").tag(0)
                        Text("kg").tag(1)
                        Text("ml").tag(2)
                        Text("ltr").tag(3)
                        Text("pcs").tag(4)
                        Text("dozen").tag(5)
                    }
                    .pickerStyle(.segmented)
                }
            }
            .toolbar {
                ToolbarItem {
                    Button(action: addItem) {
                        Image(systemName: "checkmark")
                    }
                }
            }.navigationTitle("Add Item")
        }
    }
    private func getQuantities() -> [String] {
        let quantities = QuantityType.allCases.map({$0.rawValue})
        return quantities
    }
    private func addItem() {
        UIApplication.shared.endEditing()
//        print(valuesDict)
        guard let entity = NSEntityDescription.entity(forEntityName: "Item", in: viewContext) else { return }
        let item = Item(entity: entity, insertInto: viewContext)
        item.name = name
        item.id = UUID()
        item.cost = Double(cost) ?? 0.0
        let quantityType = QuantityType.allCases[self.quantityType].rawValue
        item.quantityType = quantityType
        item.quantity = 0.0
        if let uiImage = uiImage {
            let data = uiImage.jpegData(compressionQuality: 0.3)
            item.image = UUID().uuidString
            guard let entity = NSEntityDescription.entity(forEntityName: "ImageAsset", in: viewContext) else { return }
            let imageAsset = ImageAsset(entity: entity, insertInto: viewContext)
            imageAsset.imageId = item.image
            imageAsset.data = data
        }
        do {
            try viewContext.save()
            presentedAsModal = nil
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}

struct AddItemView_Previews: PreviewProvider {
    static var previews: some View {
        AddItemView(presentedAsModal: .constant(nil))
    }
}
