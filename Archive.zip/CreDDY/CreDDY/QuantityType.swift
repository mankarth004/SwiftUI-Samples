//
//  QuantityType.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 31/12/21.
//

import Foundation
enum QuantityType: String, Codable, CaseIterable {
    case gram = "g"
    case kg = "kg"
    case litre = "ltr"
    case ml = "ml"
    case piece = "pcs"
    case dozen = "dozen"
}
