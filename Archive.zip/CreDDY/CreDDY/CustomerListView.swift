//
//  CustomerListView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 29/12/21.
//

import SwiftUI
import CoreData
import Combine

struct CustomerListView: View {
    enum CustomerFormType {
        case new, detail
    }
    @Environment(\.managedObjectContext) var viewContext
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Customer.createdDate, ascending: true)],
        animation: .default)
    private var customers: FetchedResults<Customer>
    @State private var formType: CustomerFormType = .new
    @State private var selection: Int? = nil
    @State private  var showAlertOnDelete = false
    @State private var isSharePresented: Bool = false
    @State private var offsets: IndexSet = []
    @State private var pdfUrl: URL = URL(fileURLWithPath: "")
    
    var body: some View {
        NavigationView {
            List {
                ForEach(customers) { customer in
                    NavigationLink {
                        CustomerDetailView(customer: customer)
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 8) {
                                Text(customer.wrappedName)
                                    .font(.subheadline)
                                HStack {
                                    Text("transactions:\(customer.transactionArray.count)")
                                        .font(.footnote)
                                        .foregroundColor(.gray)
                                        Divider()
                                    Text(customer.totalPendingAmount.isZero ? "paid" : String(format: "due: %0.1f", customer.totalPendingAmount))
                                            .font(.footnote)
                                            .foregroundColor(customer.totalPendingAmount.isZero ? .green : .red)
                                            .fontWeight(.medium)
                                }
                            }
                        }
                    }
                }
                .onDelete(perform: showAlert)
                .alert(isPresented: $showAlertOnDelete) {
                                Alert(title: Text("Delete Customer?"), message: Text("There are pending transactions for this customer. Do you still want to delete?"), primaryButton: .destructive(Text("Delete")) {
                                    deleteCustomers(offsets: self.offsets)
                                }, secondaryButton: .cancel())
                }
            }
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    EditButton()
                    NavigationLink(tag: 1, selection: $selection) {
                        AddCustomerView(selection: $selection)
                                .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                    } label: {
                        Button {
                            selection = 1
                        } label: {
                            Label("Add Item", systemImage: "plus")
                        }
                    }
//                    Button("Share app") {
//                        PDFCreator().exportToPDF(name: "Sample", content: self) { url in
//
//                            var pdfURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
//                            pdfURL = pdfURL.appendingPathComponent("Sample.pdf") as URL
//                            if FileManager.default.fileExists(atPath: pdfURL.path) {
//                                self.pdfUrl = pdfURL
//                                isSharePresented = true
//                            }
//                        }
//                    }
                    .sheet(isPresented: $isSharePresented, onDismiss: {
                                print("Dismiss")
                            }, content: {
//                                ActivityViewController(activityItems: [pdfData])
                                PDFKitView(url: pdfUrl)
                            })
                }
            }.navigationBarTitleDisplayMode(.large).navigationTitle("Customers")
        }
    }
    
    private func showAlert(offsets: IndexSet) {
        let index = offsets[offsets.startIndex]
        if !customers[index].totalPendingAmount.isZero {
            showAlertOnDelete = true
            self.offsets = offsets
        }else{
            deleteCustomers(offsets: offsets)
        }
    }
    private func deleteCustomers(offsets: IndexSet) {
        withAnimation {
            offsets.map { customers[$0] }.forEach(viewContext.delete)
            do {
                try viewContext.save()
                showAlertOnDelete = false
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

struct CustomerListView_Previews: PreviewProvider {
    static var previews: some View {
//        CustomerListView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
        CustomerListView()
    }
}
