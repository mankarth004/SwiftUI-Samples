//
//  TransactionDetailView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 17/01/22.
//

import SwiftUI

struct HorizontalText: View {
    var title: String
    var value: String
    var body: some View {
        HStack {
            Text(title)
                .font(.footnote)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .font(.subheadline)
                .foregroundColor(value == "paid" ? .green : .black)
                .fontWeight(value == "paid" ? .medium : .regular)
        }
    }
}
struct TransactionDetailView: View {
    
    @Environment(\.managedObjectContext) var viewContext

    @Environment(\.presentationMode) var presentationMode

    @ObservedObject var transaction: ItemTransaction

    @State var isPaid: Bool = false
    @State var isPartial: Bool = false
    @State var amount: String = ""
    @State var partialAmount: String = ""
    
    @State var enableSaveButton: Bool = false
    var body: some View {
        List {
            Section(header: Text("Details")) {
                HorizontalText(title: "Date", value: transaction.wrappedDate.fullDateString)
                HorizontalText(title: "Total", value: transaction.total.rupeeFormat)
                if transaction.pendingAmount.isZero && !transaction.isDue {
                    HorizontalText(title: "Status", value: "paid")
                }else{
                    HorizontalText(title: "Paid", value: transaction.paidAmount.rupeeFormat)
                    HorizontalText(title: "Pending", value: transaction.pendingAmount.rupeeFormat)
                    Toggle(isOn: $isPartial) {
                        Text("Partial")
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }.disabled(isPartial && transaction.paidAmount > 0.0)
                }
                if isPartial && transaction.isDue {
                    HStack {
                        TextField("Enter partial amount", text: $partialAmount)
                            .font(.subheadline)
                            .onChange(of: partialAmount) { text in
                                enableSaveButton = !text.isEmpty
                            }
                        Button {
                            if !partialAmount.isEmpty {
                                updateTransaction()
                            }
                        } label: {
                            Text("Save")
                                .font(.subheadline)
                        }
                        .padding([.leading], 16)
                        .font(.subheadline)
                        .disabled(!enableSaveButton)
                    }
                }
            }
            if (!isPaid) {
                Section(header:
                            EmptyView()
                ) {
                    HStack {
                        Button {
                            isPaid.toggle()
                            updateTransaction()
                        } label: {
                            Text("Mark as Paid")
                                .foregroundColor(.white)
                                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                        }
                    }
                    .listRowBackground(Color.accentColor)
                }
            }
            Section(header: Text("Items")) {
                ForEach(transaction.itemsArray, id: \.self) {item in
                    ItemCell(item: item, listType: .constant(.showCustomer))
                }
            }
        }.onAppear(perform: {
            isPaid = !transaction.isDue
            isPartial = transaction.isPartial
            amount = "\(transaction.total)"
        })
            .navigationTitle("Transaction Detail")
    }
    
    private func updateTransaction() {
        transaction.isDue = !isPaid
        transaction.isPartial = isPartial
        let paidAmount = isPaid ? transaction.total : ( ((Double(partialAmount) ?? 0.0) + transaction.paidAmount))
        transaction.paidAmount = paidAmount
        transaction.pendingAmount = transaction.total - paidAmount
        transaction.date = Date()
        do {
            try viewContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            print(error.localizedDescription)
        }
    }
}

struct TransactionDetailView_Previews: PreviewProvider {
    static let persistence = PersistenceController.transactionPreview
    static var item: Item = {
        let context = persistence.container.viewContext
        let newItem = Item(context: context)
        newItem.name = "Item: 1"
        newItem.cost = 1.0
        newItem.id = UUID()
        return newItem
    }()
    static var transaction: ItemTransaction = {
        let context = persistence.container.viewContext
        let newItem = ItemTransaction(context: context)
        newItem.total = 100.0
        newItem.date = Date()
        newItem.isPartial = true
        newItem.isDue = true
        newItem.id = UUID()
        newItem.addToItems(item)
        return newItem
    }()
    static var previews: some View {
        TransactionDetailView(transaction: transaction)
            .environment(\.managedObjectContext, persistence.container.viewContext)
    }
}
