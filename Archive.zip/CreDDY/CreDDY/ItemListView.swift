//
//  ItemListView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 30/12/21.
//

import SwiftUI
import CoreData

struct CustomImage: View {
    
    @FetchRequest var images: FetchedResults<ImageAsset>
    
    private let imageId: String?
    
    init(imageId: String?) {
        self.imageId = imageId
        var predicate: NSPredicate?
        if let imageId = imageId {
            predicate = NSPredicate(format: "imageId == %@", imageId)
        }
        self._images = FetchRequest(
            entity: ImageAsset.entity(),
            sortDescriptors: [],
            predicate: predicate)
    }
    
    var body: some View {
        if imageId != nil {
            Image(uiImage: UIImage(data: images.first?.data ?? Data(), scale: UIScreen.main.scale) ?? UIImage(named: "Groceries.jpeg")!)
                .resizable()
                .aspectRatio(.init(width: 60, height: 50), contentMode: .fit)
                .frame(width: 60, height: 50, alignment: .center)
        }else{
            Image(uiImage: UIImage(named: "Groceries.jpeg")!)
                .resizable()
                .aspectRatio(.init(width: 60, height: 50), contentMode: .fit)
                .frame(width: 60, height: 50, alignment: .center)
        }
    }
}

struct ItemCell: View {
    @ObservedObject var item: Item
    @Binding var listType: ItemListViewType
    var body: some View {
        HStack {
            CustomImage(imageId: item.image)
            VStack(alignment: .leading, spacing: 8) {
                Text(item.name!).font(.headline)
                HStack {
                    Text(String(format: "₹%.1f", item.cost))
                        .font(.subheadline)
                    if listType == .showCustomer {
                        Text(String(format: "x %.0f", item.quantity))
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }
                }
            }
            Spacer()
            switch listType {
            case .all:
                Image(systemName: "chevron.right")
                    .font(.footnote)
                    .foregroundColor(.accentColor)
            case .showCustomer:
                EmptyView()
            case .addToCustomer:
                VStack(alignment: .trailing) {
                    Text(String(format: "Items: ₹%.0f", item.quantity))
                        .font(.system(size: 8))
                        .foregroundColor(.gray)
                    Stepper("", value: $item.quantity, in: 0...1000)
                    Text(String(format: "Total: ₹%0.1f", item.cost * Double(item.quantity)))
                        .font(.system(size: 8))
                        .foregroundColor(.gray)
                }
            }
        }
    }
}
enum ItemListViewType {
    case all
    case addToCustomer
    case showCustomer
}
struct ItemListView: View {
    @Environment(\.managedObjectContext) var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Item.name, ascending: true)], predicate: NSPredicate(format: "transaction = nil"),
        animation: .default) private var items: FetchedResults<Item>
    
    @Environment(\.presentationMode) var presentationMode
    
    @State private var selection: Int? = nil
    
    @Binding var listType: ItemListViewType
    
    var action: ([Item]) -> ()
    
    var body: some View {
        NavigationView {
            List {
                ForEach(items) { item in
                    ItemCell(item: item, listType: $listType)
                }
                .onDelete(perform: deleteItems)
            }
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    if listType == .addToCustomer {
                        Button {
                            addItemsToCustomer()
                        } label: {
                            Text("Save")
                        }
                    }else{
                        EditButton()
                    }
                    NavigationLink(tag: 1, selection: $selection) {
                        AddItemView(presentedAsModal: $selection)
                                .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                    } label: {
                        Button {
                            selection = 1
                        } label: {
                            Label("Add Item", systemImage: "plus")
                        }
                    }
                }
            }.navigationBarTitleDisplayMode(.large).navigationTitle("All Items")
        }
    }
    private func addItemsToCustomer() {
        let cartItems = items.filter({$0.quantity > 0})
        action(cartItems)
        selection = nil
        if listType == .addToCustomer {
            presentationMode.wrappedValue.dismiss()
        }
    }
    
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)
            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

struct ItemListView_Previews: PreviewProvider {
    static var previews: some View {
        ItemListView(listType: .constant(.addToCustomer)){ items in
            
        }.environment(\.managedObjectContext, PersistenceController.itemsPreview.container.viewContext)
    }
}
