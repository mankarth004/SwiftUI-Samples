//
//  MainView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 30/12/21.
//

import SwiftUI

struct CustomTab: Identifiable {
    let image, title: String
    let id: Int
}

struct MainView: View {
        
    @State var selectedTab: Int = 0
    
    private var tabs = [
        CustomTab(image: "person.2.fill", title: "Customers", id: 0),
        CustomTab(image: "list.bullet", title: "Items", id: 1),
        CustomTab(image: "gear", title: "Settings", id: 2)]
    var body: some View {
        VStack {
            ZStack {
                switch selectedTab {
                case 0:
                    CustomerListView()
                        .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                case 1:
                    ItemListView(listType: .constant(.all)) {items in
                        
                    }
                    .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                case 2:
                    SettingsView()
                default:
                    EmptyView()
                }
            }
            Spacer()
            HStack {
                ForEach(tabs) {tab in
                    Button {
                        selectedTab = tab.id
                    } label: {
                        Spacer()
                        VStack {
                            Image(systemName: tab.image)
                                .foregroundColor(selectedTab == tab.id ? .red : Color(.label))
                                .font(Font.system(size: selectedTab == tab.id ? 27 : 24))
                            Text(tab.title)
                                .font(.footnote)
                                .fontWeight(selectedTab == tab.id ? .bold : .light)
                                .foregroundColor(selectedTab == tab.id ? .red : Color(.label))
                        }
                        Spacer()
                    }
                }
            }
        }
    }
}

struct MainViewRegular: View {
    
    @EnvironmentObject private var stateManager: StateManager
    
    var body: some View {
        TabView(selection: $stateManager.tabSelection) {
            CustomerListView()
                .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                .environmentObject(stateManager)
                .tabItem {
                    Label("Customers", systemImage: stateManager.tabSelection == 0 ? "person.2.fill" : "person.2")
                }
            ItemListView(listType: .constant(.all)) {items in
                
            }
                .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                .environmentObject(stateManager)
                .tabItem {
                    Label("Items", systemImage: "list.bullet")
                }
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
        }
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
