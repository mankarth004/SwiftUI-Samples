//
//  AddCustomerView.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 29/12/21.
//

import SwiftUI
import CoreData

struct AddCustomerView: View {
    @Environment(\.managedObjectContext) var viewContext

    @Binding var selection: Int?

    @State var name: String = ""
    @State var mobile: String = ""
    @State var email: String = ""
    @State var address: String = ""
    
    var body: some View {
        Form {
            HStack {
                Text("Name")
                TextField("Enter customer name", text: $name)
                    .multilineTextAlignment(.trailing)
            }
            HStack {
                Text("Mobile")
                TextField("Enter mobile number", text: $mobile)
                    .multilineTextAlignment(.trailing)
                    .keyboardType(.phonePad)
            }
            HStack {
                Text("Email")
                TextField("Enter emailId", text: $email)
                    .multilineTextAlignment(.trailing)
                    .keyboardType(.emailAddress)
                    .textCase(.lowercase)
            }
            VStack(alignment: .leading){
                Text("Address")
                TextEditor(text: $address)
                    .frame(height: 80, alignment: .leading)
            }
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: addCustomer) {
                    Image(systemName: "checkmark")
                }
            }
        }
        .navigationTitle("Add Customer")
    }
    private func addCustomer() {
        guard !name.isEmpty && !mobile.isEmpty else {
            return
        }
        UIApplication.shared.endEditing()
        guard let entity = NSEntityDescription.entity(forEntityName: "Customer", in: viewContext) else { return }
        let customer = Customer(entity: entity, insertInto: viewContext)
        customer.name = name
        customer.mobile = mobile
        customer.email = email
        customer.address = address
        customer.id = UUID()
        customer.createdDate = Date()
        do {
            try viewContext.save()
            selection = nil // poping the view
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}

struct AddCustomerView_Previews: PreviewProvider {
    static var previews: some View {
        AddCustomerView(selection: .constant(nil))
    }
}
