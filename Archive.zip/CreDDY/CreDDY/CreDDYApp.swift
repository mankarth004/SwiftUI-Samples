//
//  CreDDYApp.swift
//  CreDDY
//
//  Created by kartheek.manthoju on 29/12/21.
//

import SwiftUI

@main
struct CreDDYApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
