//
//  Notes+CoreDataProperties.swift
//  Notes
//
//  Created by kartheek.manthoju on 27/01/22.
//
//

import Foundation
import CoreData


extension Notes {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Notes> {
        return NSFetchRequest<Notes>(entityName: "Notes")
    }

    @NSManaged public var content: String?
    @NSManaged public var date: Date?
    @NSManaged public var id: UUID?

}

extension Notes : Identifiable {
    public var wrappedDate: Date {
        return date ?? Date()
    }
}
