//
//  Notes+CoreDataClass.swift
//  Notes
//
//  Created by kartheek.manthoju on 27/01/22.
//
//

import Foundation
import CoreData

@objc(Notes)
public class Notes: NSManagedObject {

}
