//
//  NotesList.swift
//  Notes
//
//  Created by kartheek.manthoju on 27/01/22.
//

import SwiftUI

struct NotesList: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Notes.date, ascending: true)],
        animation: .default)
    private var notes: FetchedResults<Notes>
    
    @State var wrappedNotes: [Notes] = []
    
    @State private var isScreenActive = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach($wrappedNotes) { $note in
                    NavigationLink {
                        AddNotesView(existingNote: $note)
                            .environment(\.managedObjectContext, viewContext)
                    } label: {
                        Text(note.content ?? "")
                    }
                }
                .onDelete(perform: deleteCustomers)
            }
            .navigationTitle("Notes")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(isActive: $isScreenActive) {
                        AddNotesView(existingNote: nil)
                            .environment(\.managedObjectContext, viewContext)
                    } label: {
                        Button {
                            isScreenActive = true
                        } label: {
                            Image(systemName: "plus")
                        }
                    }
                }
            }
            .onAppear {
                wrappedNotes = notes.sorted {
                    $0.wrappedDate > $1.wrappedDate
                }
            }
        }
    }
    
    private func deleteCustomers(offsets: IndexSet) {
        let index = offsets[offsets.startIndex]
        let note = wrappedNotes[index]

        wrappedNotes.remove(at: index)
        
        print(note.content ?? "")
        
        withAnimation {
//            offsets.map { notes[$0] }.forEach(viewContext.delete)
            viewContext.delete(note)
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

struct NotesList_Previews: PreviewProvider {
    static var previews: some View {
        NotesList()
            .environment(\.managedObjectContext, PersistenceController.notePreview.container.viewContext)
    }
}
