//
//  AddNotesView.swift
//  Notes
//
//  Created by kartheek.manthoju on 27/01/22.
//

import SwiftUI

struct AddNotesView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @State private var contentText: String = ""
    
    @State private var isNotesCreated = false
    @State var note: Notes?

    var existingNote: Binding<Notes>? = nil
    
    var body: some View {
        VStack {
            TextEditor(text: $contentText)
                .onChange(of: contentText) { newValue in
                    saveNotes(contentText: newValue)
                }
                .onAppear {
                    contentText = existingNote?.wrappedValue.content ?? ""
                }
        }
    }
    private func saveNotes(contentText: String) {
        if existingNote == nil {
//            Saving new note
            if !isNotesCreated {
                note = Notes(context: viewContext)
                note?.id = UUID()
                note?.date = Date()
                isNotesCreated = true
            }
            note?.content = contentText
        }else {
//            Saving existing note
            existingNote?.wrappedValue.date = Date()
            existingNote?.wrappedValue.content = contentText
        }
        
        do {
            try viewContext.save()
        } catch {
            print(error.localizedDescription)
        }
    }
}

struct AddNotesView_Previews: PreviewProvider {
    static let persistence = PersistenceController.notePreview
    
    @State static var note: Notes = {
        let context = persistence.container.viewContext
        let newNote = Notes(context: context)
        newNote.content = ""
        return newNote
    }()
    static var previews: some View {
        AddNotesView(existingNote: $note)
    }
}
