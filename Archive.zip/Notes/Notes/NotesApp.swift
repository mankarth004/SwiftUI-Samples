//
//  NotesApp.swift
//  Notes
//
//  Created by kartheek.manthoju on 27/01/22.
//

import SwiftUI

@main
struct NotesApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            NotesList()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
