//
//  SampleAppApp.swift
//  SampleApp
//
//  Created by kartheek.manthoju on 24/01/22.
//

import SwiftUI

@main
struct SampleAppApp: App {
    var body: some Scene {
        WindowGroup {
            TabbarView()
        }
    }
}
