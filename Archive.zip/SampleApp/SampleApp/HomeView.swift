//
//  HomeView.swift
//  SampleApp
//
//  Created by kartheek.manthoju on 24/01/22.
//

import SwiftUI

struct StackedText: View {
    var title: String?
    @Binding var value: String
    
    var body: some View {
        HStack {
            Text(title ?? "")
                .font(.footnote)
                .foregroundColor(.gray)
            Divider()
                .frame(height: 20)
            Spacer()
            TextField("Enter \(title ?? "")", text: $value)
                .font(.subheadline)
        }
        .padding()
        .clipShape(Capsule())
    }
}

struct HomeView: View {
    @State var counter: Int = 0
    @State var name: String = ""
    @State var value: String = ""
    
    var body: some View {
        ZStack {
            HStack(spacing: 0) {
                Rectangle()
                    .foregroundColor(.blue)
                    .ignoresSafeArea()
                Rectangle()
                    .foregroundColor(.green)
                    .ignoresSafeArea()
            }
            .frame(height: 1000)
            .rotationEffect(.degrees(45))

            VStack {
                Text("Home Updated and it is now multilined")
                    .fontWeight(.heavy)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                    .padding(.leading, 30.0)
                    .foregroundColor(.green)
                    .background(Color.yellow)
                    .font(.largeTitle)
                StackedText(title: "Name", value: $value)
                Button {
                    counter += 1
                    print("Changed text is: \(name)")
                } label: {
                    Image(systemName: "house")
                    Text("Click Me")
                }
                .padding()
                .foregroundColor(.white)
                .background(Color.blue)
                .clipShape(Capsule())
                .shadow(color: .yellow, radius: 10, x: 5, y: 5)
                Text("Counter: \(counter)")
                    .font(.largeTitle)
                    .foregroundColor(.red)
                TextField("Enter name", text: $name)
                    .padding()
                    .onChange(of: name) { newValue in
                        
                    }
                Text("name is: \(name)")
                Text("Stacked name is: \(value)")
            }
            .padding()
            .background(Color.white)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
