//
//  TabView.swift
//  SampleApp
//
//  Created by kartheek.manthoju on 27/01/22.
//

import SwiftUI

struct TabbarView: View {
    @State var selection: Int?
    @State var title: String?
    var body: some View {
        TabView(selection: $selection) {
            NameListView()
                .tabItem {
                    VStack {
                        Image(systemName: "person")
                        Text("People")
                    }
                }
            PAHomeView()
                .tabItem {
                VStack {
                    Image(systemName: "dollarsign.circle.fill")
                    Text("People")
                }
            }
            HomeView()
                .tabItem {
                VStack {
                    Image(systemName: "house")
                    Text("Home")
                }
            }
        }
    }
}

struct TabbarView_Previews: PreviewProvider {
    static var previews: some View {
        TabbarView(selection: 0, title: "")
    }
}
