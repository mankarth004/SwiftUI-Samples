//
//  PAHomeView.swift
//  SampleApp
//
//  Created by kartheek.manthoju on 25/01/22.
//

import SwiftUI

struct PAHomeView: View {
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(.green)
                .ignoresSafeArea()
            VStack {
                HStack {
                    Image("sample")
                        .resizable()
                        .aspectRatio(CGSize(width: 70, height: 70), contentMode: .fit)
                        .frame(width: 70, height: 70)
                        .clipShape(Circle())
                        .overlay(
                            Circle()
                                .stroke(Color.white, lineWidth: 4)
                        )
                    
                    VStack(alignment: .leading) {
                        Text("Good Morning")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        Text("Stephanie")
                            .font(.title)
                            .foregroundColor(.white)
                    }
                    Spacer()
                }
                .padding()
                
                ScrollView {
                    ZStack {
                        Color.white
                        VStack {
                            Image(systemName: "dollarsign.circle.fill")
                                .foregroundColor(.green)
                                .font(.system(size:40))
                            Text("73,850.37")
                                .foregroundColor(.green)
                                .font(.system(size:40))
                                .fontWeight(.bold)
                            Text("Account balance")
                                .font(.headline)
                                .foregroundColor(.gray)
                            VStack {
                                Divider()
                                    .foregroundColor(.gray)
                                HStack {
                                    Text("Account balance")
                                        .font(.headline)
                                        .foregroundColor(.gray)
                                    NavigationLink {
                                        HomeView()
                                    } label: {
                                        Button {
                                            
                                        } label: {
                                            Image(systemName: "questionmark.circle")
                                                .foregroundColor(.gray)
                                        }
                                    }
                                    
                                    Spacer()
                                    Text("$26,149.63")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.green)
                                }
                                Spacer(minLength: 20)
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text("Spend Tracker")
                                            .fontWeight(.bold)
                                        Text("$204,267.36")
                                            .fontWeight(.bold)
                                    }
                                    .foregroundColor(.green)
                                    .font(.title)
                                    Spacer()
                                }
                                Image("linegraph")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }.padding(20)
                        }
                        .padding([.top], 40)
                        
                    }
                }
                .cornerRadius(60, corners: [.topLeft])
            }
            Spacer()
        }
    }
}

struct PAHomeView_Previews: PreviewProvider {
    static var previews: some View {
        PAHomeView()
    }
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape( RoundedCorner(radius: radius, corners: corners) )
    }
}

struct RoundedCorner: Shape {

    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}
