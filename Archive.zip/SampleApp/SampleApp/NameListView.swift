//
//  NameListView.swift
//  SampleApp
//
//  Created by kartheek.manthoju on 24/01/22.
//

import SwiftUI

struct Person: Identifiable {
    var name, study: String
    let id: Int
}

struct PersonView: View {
    @Binding var person: Person

    @State var selectedItem: String = "Apple"
    var items = ["Apple", "Banana", "Grapes", "Gua"]
    @State var isPresent = false
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(person.name)
                .font(.subheadline)
            Text(person.study)
                .font(.footnote)
                .foregroundColor(.gray)
            Picker("Select Item", selection: $selectedItem) {
                ForEach(items, id: \.self) {item in
                    Text(item)
                        .tag(items.firstIndex(of: selectedItem))
                }
            }
            .pickerStyle(.menu)
            Toggle("Is Present", isOn: $isPresent)
                .onChange(of: isPresent) { newValue in
                    if isPresent {
                        person.name = person.name + " is present today"
                    }
                }
        }
    }
}

struct PersonDetail: View {
//    @Binding var isScreenActive: Bool
    
    var callback: ((String) -> ())?
    
    var body: some View {
        VStack {
            Button {
//                isScreenActive = false
                if callback != nil {
                    callback!("Kartheek")
                }
            } label: {
                Text("Take me back")
            }
        }
    }
}

struct NameListView: View {
    @State private var people: [Person] = [Person(name: "John Doe", study: "BE", id: 0)]
    @State private var name: String = ""
    @State private var study: String = ""
    @State private var isScreenActive = false
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    TextField("Name", text: $name)
                        .textFieldStyle(.roundedBorder)
                    TextField("Study", text: $study)
                        .textFieldStyle(.roundedBorder)
                    Button {
                        people.append(Person(name: name, study: study, id: Int.random(in: 0..<10000)))
                        name = ""
                        study = ""
                        UIApplication.shared.endEditing()
                    } label: {
                        Image(systemName: "checkmark")
                    }
                }
                .padding()
                List {
                    Section(header: HStack {
                        Text("People")
                    }) {
                        ForEach($people) { $person in
                            NavigationLink(destination: PAHomeView()) {
                                PersonView(person: $person)
                            }
                        }
                    }
                }
                
                NavigationLink(isActive: $isScreenActive) {
                    PersonDetail()
                } label: {
                    Button {
                        isScreenActive = true
                    } label: {
                        Text("Without closure")
                    }
                    .padding()
                }
                NavigationLink(isActive: $isScreenActive) {
                    PersonDetail() { title in
                        print(title)
                        isScreenActive = false
                    }
                } label: {
                    Button {
                        isScreenActive = true
                    } label: {
                        Text("With Closure")
                    }
                    .padding()
                }
            }
            .navigationTitle(Text("People"))
            .navigationBarTitleDisplayMode(.inline)
//                .toolbar {
//                    ToolbarItemGroup(placement: .navigationBarTrailing) {
//                        Button {
//
//                        } label: {
//                            Image(systemName: "checkmark")
//                        }
//                    }
//                }
        }
    }
}

struct NameListView_Previews: PreviewProvider {
    static var previews: some View {
        NameListView()
            .preferredColorScheme(.dark)
    }
}

extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
